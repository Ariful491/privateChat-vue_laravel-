@extends('layouts.app')

@section('content')
<div id="app">
    <main-app></main-app>
</div>


@endsection
